<?php
// Include konfigurasi file database
require_once "database.php";

// Memeriksa apakah formulir dikirim
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Mengambil nilai dari formulir
    $judul = $_POST["judul_buku"];
    $notes = $_POST["pengarang"];
    $kategori = $_POST["deskripsi"];

    // Menyiapkan pernyataan INSERT
    $sql = "INSERT INTO catatan (judul, notes, kategori) VALUES (?, ?, ?)";

    if ($stmt = $conn->prepare($sql)) {
        // Mengikat parameter ke pernyataan
        $stmt->bind_param("sss", $judul, $notes, $kategori);

        // Mengeksekusi pernyataan
        if ($stmt->execute()) {
            // Redirect ke halaman lain setelah data disimpan
            header("location: index.php");
            exit();
        } else {
            echo "Ada masalah. Silakan coba lagi!";
        }

        // Menutup pernyataan
        $stmt->close();
    }

    // Menutup koneksi
    $conn->close();
}
?>