<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Aplikasi Catatan</title>
	
	<link rel="icon" href="img/logo.jpg" type="image/x-icon">
	<link rel="stylesheet" href="bootstrap-5.1.3-dist\css\bootstrap.css">
    <link rel="stylesheet" href="fontawesome-free-6.0.0-web\css\all.min.css">
    <style type="text/css">
    	.wrapper{
    		width: 700px;
   			margin: 0 auto;
    		margin-bottom: 25px;
		}
    </style>
</head>
<body>
	<div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-14">
                    <div class="page-header"><br><br>
                        <h2>Aplikasi NOTES</h2>
                        <a href="buat.php" class="btn btn-success pull-right">Tambah Baru</a><br><br>
                    </div>
                    <?php
                    // Include config file
                    require_once "database.php";

                    // Attempt select query execution
                    $sql = "SELECT * FROM catatan";
                    if($result = mysqli_query($link, $sql)){
                        if(mysqli_num_rows($result) > 0){
                    echo "<table class='table table-responsive table-bordered table-striped'>";
                                echo "<thead>";
                                    echo "<tr>";
                                        echo "<th>No</th>";
                                        echo "<th>Judul</th>";
                                        echo "<th>Notes</th>";
                                        echo "<th>Kategori</th>";
                                    echo "</tr>";
                                echo "</thead>";
                                echo "<tbody>";
                                while($row = mysqli_fetch_array($result)){
                                    echo "<tr>";
                                        echo "<td>" . $row['id'] . "</td>";
                                        echo "<td>" . $row['judul'] . "</td>";
                                        echo "<td>" . $row['notes'] . "</td>";
                                        echo "<td>" . $row['kategori'] . "</td>";
                                    echo "</tr>";
                                }
                                echo "</tbody>";
                            echo "</table>";
                            // Free result set
                            mysqli_free_result($result);
                        } else{
                            echo "<p class='lead'><em>No records were found.</em></p>";
                        }
                    } else{
                        echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
                    }

                    // Close connection
                    mysqli_close($link);
                    ?>

                    <!--
                    <p>Untuk menambahkan catatan baru, silahkan diisi.</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                        <div class="form-group <?php echo (!empty($judul_err)) ? 'has-error' : ''; ?>">
                            <label style="margin-bottom: 10px;">judul</label>
                            <input type="text" name="judul" class="form-control" value="<?php echo $judul; ?>">
                            <span class="help-block"><?php echo $judul_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($notes_err)) ? 'has-error' : ''; ?>">
                            <label style="margin-bottom: 10px;">Notes</label>
                            <input type="text" name="notes" class="form-control" value="<?php echo $notes; ?>"></input>
                            <span class="help-block"><?php echo $notes_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($kategori_err)) ? 'has-error' : ''; ?>">
                            <label style="margin-bottom: 10px;">Kategori</label>
                            <textarea cols="30" width="100%" type="text" name="kategori" class="form-control" value="<?php echo $kategori; ?>; ?>"></textarea>
                            <span class="help-block"><?php echo $kategori_err;?></span>
                        </div>
                        <br>
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="edit.php" class="btn btn-primary">Edit</a>
                        <a href="tampil.php" class="btn btn-primary">Tampil</a>
                        <a href="index.php" class="btn btn-default">Cancel</a>
                    </form>
                -->
                </div>
            </div>
        </div>
    </div>
</body>
</html>
