<?php
// Include config file
require_once "database.php";

// Define variables and initialize with empty values
$judul = $notes = $kategori = $id  = "";
$judul_err = $notes_err = $kategori_err = "";

// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Validate judul
    $input_judul = trim($_POST["judul"]);
    if(empty($input_judul)){
        $judul_err = "Silahkan Isi judul Buku.";
    } elseif(!filter_var($input_judul, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
        $judul_err = "Silahkan Isi judul Buku dengan yang lain.";
    } else{
        $judul = $input_judul;
    }

    // Validate Notes
    $input_notes = trim($_POST["notes"]);
    if(empty($input_notes)){
        $notes_err = "Silahkan isi Catatan kamu.";
    } elseif(!ctype_digit($input_notes)){
        $notes_err = "Silahkan ganti isi Catatan kamu.";
    } else{
        $notes = $input_notes;
    }

    // Validate penerbit
    $input_kategori = trim($_POST["kategori"]);
    if(empty($input_kategori)){
        $kategori_err = "Silahkan isi kategori singkat Buku";
    } else{
        $kategori = $input_kategori;
    }

    // Check input errors before inserting in database
    if(empty($judul_err)&& empty($notes_err)&& empty($kategori_err)){
        // Prepare an insert statement
        $sql = "INSERT INTO catatan (judul,notes,kategori,id) VALUES (?, ?, ?, ?)";

        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "sssi", $param_judul, $param_notes, $param_kategori, $id);

            // Set parameters
            $param_judul = $judul;
            $param_notes = $notes;
            $param_kategori = $kategori;
            $param_id = $id;

            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records created successfully. Redirect to landing page
                header("location: index.php");  
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }

        // Close statement
        mysqli_stmt_close($stmt);
    }

    // Close connection
    mysqli_close($link);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Aplikasi Catatan</title>
	
	<link rel="icon" href="img/logo.jpg" type="image/x-icon">
	<link rel="stylesheet" href="bootstrap-5.1.3-dist\css\bootstrap.css">
    <link rel="stylesheet" href="fontawesome-free-6.0.0-web\css\all.min.css">
    <style type="text/css">
    	.wrapper{
    		width: 700px;
   			margin: 0 auto;
    		margin-bottom: 25px;
		}
    </style>
</head>
<body>
	<div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-14">
                    <div class="page-header"><br><br>
                        <h2>Aplikasi NOTES</h2>
                    </div>
                    <p>Untuk menambahkan catatan baru, silahkan diisi.</p>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                        <div class="form-group <?php echo (!empty($judul_err)) ? 'has-error' : ''; ?>">
                            <label style="margin-bottom: 10px;">judul</label>
                            <input type="text" name="judul" class="form-control" value="<?php echo $judul; ?>">
                            <span class="help-block"><?php echo $judul_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($notes_err)) ? 'has-error' : ''; ?>">
                            <label style="margin-bottom: 10px;">Notes</label>
                            <input type="text" name="notes" class="form-control" value="<?php echo $notes; ?>"></input>
                            <span class="help-block"><?php echo $notes_err;?></span>
                        </div>
                        <div class="form-group <?php echo (!empty($kategori_err)) ? 'has-error' : ''; ?>">
                            <label style="margin-bottom: 10px;">Kategori</label>
                            <textarea cols="30" width="100%" type="text" name="kategori" class="form-control" value="<?php echo $kategori; ?>; ?>"></textarea>
                            <span class="help-block"><?php echo $kategori_err;?></span>
                        </div>
                        <br>
                        <input type="submit" class="btn btn-primary" value="Submit">
                        <a href="edit.php" class="btn btn-primary">Edit</a>
                        <a href="tampil.php" class="btn btn-primary">Tampil</a>
                        <a href="index.php" class="btn btn-default">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>














