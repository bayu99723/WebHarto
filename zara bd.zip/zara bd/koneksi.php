<?php

$server = "localhost"; //nama server
$user = "root"; //username server
$pass = ""; //password
$dbase = "db_crudku"; //database yang dipakai

//Membuat koneksi
$koneksi = mysqli_connect($server, $user, $pass, $dbase);

//Mengecek koneksi
if(!$koneksi) {
	die("Koneksi gagal: ".mysqli_connect_error());
}

echo "Koneksi Berhasil";

?>
