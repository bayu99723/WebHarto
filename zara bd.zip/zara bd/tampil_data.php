<html>
<head>
	<title>Tampil Data</title>
</head>
<body>
	<a href = "tambah_data.php">Tambah Data</a>
	<h3>Tampil Data</h3>

	<table border = "1">
		<head>
			<th>No</th>
			<th>Nama Mahasiswa</th>
			<th>Email Mahasiswa</th>
			<th>Tanggal</th>
			<th colspan="2">Aksi</th>
		</head>
		<body>
			<?php
			include "koneksi.php";

			//query sql
			$sql = "SELECT * from Mahasiswa ORDER By id_mhs DESC";
			$query = mysqli_query($koneksi, $sql) or die (mysqli_error());

			$no = 1; //no.urut

			while($data = mysqli_fetch_array($query)) {

				$id = $data["id_mhs"];
				$id = $data["nama_mahasiswa"];
				$id = $data["email_mahasiswa"];
				$id = $data["tanggal"];

				echo "<tr>
				<td>$No<td>
				<td>$nm<td>
				<td>$em</td>
				<td>$tg</td>
				<td>
				<a href = 'rubah_data.php?rubah_id = $id'>Rubah</a>
				<a href = 'hapus_data.php?hapus_id = $id'>Hapus</a>
				</td>
				</tr>";
				$no++;
			}
		?>
	</body>
</table>
</body>
</html>