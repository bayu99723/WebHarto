<?php
include"koneksi.php";

$nm = $_POST["nama"];
$em = $_POST["mail"];
$id = $_POST["id"];

date_default_timezone_set("Asia/Jakarta");

$tgl = date("Y:n:d");

//query sql
$sql = "UPDATE mahasiswa
SET nama_mahasiswa ='$nm',
email_mahasiswa ='$em',
tanggal ='$tg'
WHERE id_mhs = '$id'";

$query = mysqli_query($koneksi, $sql) or die (mysqli_error());

if($query) {
	echo "Data berhasil dirubah";
	header('location:tampil_data.php');
} else {
	echo "Error".$sql."<br>".mysqli_error($koneksi);
}
mysqli_close($koneksi);
?>