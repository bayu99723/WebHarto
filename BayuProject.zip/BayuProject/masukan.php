<?php
// Sertakan file koneksi.php
include 'koneksi.php';

// Periksa apakah form telah disubmit dengan metode POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form dan amankan
    $name = mysqli_real_escape_string($koneksi, $_POST['name']);
    $email = mysqli_real_escape_string($koneksi, $_POST['email']);
    $pesan = mysqli_real_escape_string($koneksi, $_POST['message']);

    // Query untuk menyimpan data ke database
    $query = "INSERT INTO terkirim (nama, email, pesan) VALUES ('$name', '$email', '$pesan')";

    // Jalankan query dan periksa hasilnya
    if (mysqli_query($koneksi, $query)) {
        // Jika berhasil, tampilkan pesan sukses
        echo "Data telah terkirim!";
    } else {
        // Jika gagal, tampilkan pesan error dan error dari MySQL
        echo "Gagal mengirim pesan. Silakan coba lagi.<br>";
        echo "Error: " . mysqli_error($koneksi);
    }

    // Tutup koneksi ke database
    mysqli_close($koneksi);
} else {
    echo "Form harus dikirim dengan metode POST.";
}
?>
