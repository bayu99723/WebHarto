<!DOCTYPE html>
<html lang="en">
<head>
    <title>BellMondo Cafe</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" href="img/logo.jpg" type="image/x-icon">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        h1, h2, h3, h4, h5, h6 {
            font-family: 'Playfair Display', serif;
        }
        .menu-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .menu-item {
            flex: 1 1 calc(33.333% - 20px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            border-radius: 10px;
            overflow: hidden;
        }
        .menu-item img {
            width: 100%;
            height: auto;
        }
        .menu-item h3 {
            padding: 15px;
            background-color: #f8f8f8;
        }
        .testimonial-section {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }
        .testimonial-card {
            flex: 1 1 calc(33.333% - 20px);
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            text-align: center;
        }
        .testimonial-card img {
            border-radius: 50%;
            width: 80px;
            height: 80px;
            object-fit: cover;
            margin-bottom: 10px;
        }
        .contact-section {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }
        .contact-details, .contact-form {
            flex: 1 1 calc(50% - 20px);
        }
        .contact-form input, .contact-form textarea {
            width: 100%;
            margin-bottom: 10px;
            padding: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .contact-form button {
            padding: 15px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 5px;
        }
    </style>
</head>
<body>

<!-- Navbar (sit on top) -->
<div class="w3-top">
  <div class="w3-bar w3-white w3-padding w3-card" style="letter-spacing:4px;">
    <a href="#home" class="w3-bar-item w3-button">BellMondo Cafe</a>
    <div class="w3-right w3-hide-small" style="text-decoration: ">
      <a href="#about" class="w3-bar-item w3-button">About</a>
      <a href="#menu" class="w3-bar-item w3-button">Menu</a>
      <a href="#testimoni" class="w3-bar-item w3-button">Testimoni</a>
      <a href="#contact" class="w3-bar-item w3-button">Contact</a>
    </div>
  </div>
</div>

<!-- Carousel -->
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel" data-interval="4000">
    <ol class="carousel-indicators">
        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner" style="height: 500px;">
        <div class="carousel-item active">
            <img src="img/Lobster Thermidor.jpg" class="d-block w-100" alt="Lobster Thermidor">
            <div class="carousel-caption d-none d-md-block">
                <h5>Lobster Thermidor</h5>
            </div>
        </div>
        <div class="carousel-item">
            <img src="img/Peking Duck.jpg" class="d-block w-100" alt="Peking Duck">
            <div class="carousel-caption d-none d-md-block">
                <h5>Peking Duck</h5>
            </div>
        </div>
        <div class="carousel-item">
            <img src="img/Opera Cake.jpg" class="d-block w-100" alt="Opera Cake">
            <div class="carousel-caption d-none d-md-block">
                <h5>Opera Cake</h5>
            </div>
        </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>

<!-- Page content -->
<div class="w3-content" style="max-width:1100px">

  <!-- About Section -->
  <div class="w3-row w3-padding-64" id="about">
    <div class="w3-col m6 w3-padding-large w3-hide-small">
     <img src="img/logo.jpg" class="w3-round w3-image w3-opacity-min" alt="Logo" width="600" height="750" style="margin-top: 20px;">
    </div>

    <div class="w3-col m6 w3-padding-large">
      <h1 class="w3-center">Welcome to BellMondo Cafe</h1><br>
      <h5 class="w3-center">Tradisi sejak 1889</h5>
      <p class="w3-large">Cafe ini didirikan di Medan,Sumatera Utara oleh Bayu Anggoro dalam dengan visi, dedikasi yang tinggi untuk menyajikan pengalaman kafe mewah kepada para pelanggan setia, dan telah menjadi destinasi yang terkenal untuk pecinta makanan mewah. Kami hanya menggunakan bahan-bahan <span class="w3-tag w3-light-grey">musiman</span> yang berkualitas terbaik.</p>
      <p class="w3-large w3-text-grey w3-hide-medium">Kami mengutamakan kualitas dan keaslian dalam setiap hidangan kami. Setiap kunjungan ke Cafe BellMondo adalah pengalaman yang tak terlupakan, dengan nuansa tradisional yang kental namun tetap memancarkan kemewahan.</p>
    </div>
  </div>
  
  <hr>
  
  <!-- Menu Section -->
  <div class="w3-row w3-padding-64" id="menu">
    <h1 class="w3-center">Our Menu</h1><br>
    <div class="menu-grid">
      <div class="menu-item">
        <img src="img/Lobster Thermidor.jpg" alt="Lobster Thermidor">
        <h3>Lobster Thermidor</h3>
        <p>Lobster Thermidor adalah hidangan mewah yang memadukan kelembutan daging lobster dengan saus krim yang kaya dan keju panggang, menciptakan perpaduan rasa yang luar biasa memanjakan lidah.</p>
        <a href="https://wa.me/083842803207?text=I%20want%20to%20order%20Lobster%20Thermidor" class="w3-button w3-block w3-black">Order</a>
      </div>
      <div class="menu-item">
        <img src="img/Peking Duck.jpg" alt="Peking Duck">
        <h3>Peking Duck</h3>
        <p>sajian ikonik yang menawarkan perpaduan sempurna antara kulit bebek yang renyah, daging yang lembut, dan saus hoisin yang manis gurih, menjadikannya pengalaman kuliner yang tak terlupakan.</p>
        <a href="https://wa.me/083842803207?text=I%20want%20to%20order%20Peking%20Duck" class="w3-button w3-block w3-black">Order</a>
      </div>
      <div class="menu-item">
        <img src="img/Opera Cake.jpg" alt="Opera Cake">
        <h3>Opera Cake</h3>
        <p>Opera Cake adalah kue elegan dengan lapisan almond sponge cake, krim mentega kopi, dan ganache cokelat, menciptakan harmoni rasa yang kaya dan mewah.</p>
        <a href="https://wa.me/083842803207?text=I%20want%20to%20order%20Opera%20Cake" class="w3-button w3-block w3-black">Order</a>
      </div>
    </div>
  </div>

  <hr>

  <!-- Testimonials Section -->
  <div class="w3-container w3-padding-64" id="testimoni">
    <h1 class="w3-center">Testimoni</h1><br>
    <div class="testimonial-section">
      <div class="testimonial-card">
        <img src="img/like1.jpg" alt="Reinhard">
        <p>"The food was absolutely wonderful, from preparation to presentation, very pleasing. Thank you for an amazing experience!"</p>
        <h5><b>- Reinhard</b></h5>
      </div>
      <div class="testimonial-card">
        <img src="img/like2.jpg" alt="Jack">
        <p>"Everything was perfect, the food was delicious, the service was outstanding. I am truly impressed!"</p>
        <h5><b>- Jack</b></h5>
      </div>
      <div class="testimonial-card">
        <img src="img/like3.jpg" alt="Michael">
        <p>"I was delighted with the quality of the food and the impeccable service provided. Kudos to the team!"</p>
        <h5><b>- Michael</b></h5>
      </div>
    </div>
  </div>

  <hr>

  <!-- Contact Section -->
  <div class="w3-container w3-padding-64" id="contact">
    <h1 align="center">Contact Us</h1><br>
    <div class="contact-section">
      <div class="contact-details">
        <div>
          <p class="w3-text-blue-grey w3-large"><b>Phone: 0838-4280-3207</b></p>
        </div>
        <div>
          <p class="w3-text-blue-grey w3-large"><b>Email: bayudeveloper07@gmail.com</b></p>
        </div>
        <div>
          <p class="w3-text-blue-grey w3-large"><b>Address: Jalan Sisingamangaraja, Medan Kota</b></p>
        </div>
      </div>
      <div class="contact-form">
        <form action="masukan.php" method="post">
          <input class="w3-input" type="text" placeholder="Name" required name="name">
          <input class="w3-input" type="email" placeholder="Email" required name="email">
          <textarea class="w3-input" placeholder="Message" required name="message"></textarea>
          <button class="w3-button w3-light-grey" type="submit">SEND MESSAGE</button>
        </form>
      </div>
    </div>
  </div>

<!-- End page content -->
</div>

  <!-- Footer -->
  <footer class="w3-center w3-light-grey w3-padding-32">
    <p>&copy; 2024 Powered by Bayu Anggoro. All Rights Reserved.</p>
  </footer>

  <!-- Bootstrap JS, Popper.js, and jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
