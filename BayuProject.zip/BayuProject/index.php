<!DOCTYPE html>
<html lang="en">
<head>
    <title>BellMondo Cafe</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <style>
        body {
            font-family: "Times New Roman", Georgia, Serif;
        }
        h1, h2, h3, h4, h5, h6 {
            font-family: "Playfair Display";
            letter-spacing: 5px;
        }
        .menu-container {
            display: flex;
            flex-wrap: nowrap;
            overflow-x: auto;
        }
        .menu-card {
            flex: 0 0 auto;
            margin: 0 10px;
            width: 300px;
        }
        .testimoni-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
        }
        .testimoni-card {
            flex: 0 0 auto;
            margin: 10px;
            width: 300px;
            border: 1px solid #ccc;
            padding: 10px;
            border-radius: 10px;
        }
        .contact-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }
        .contact-details, .contact-form {
            flex: 1;
            min-width: 300px;
            margin: 10px;
        }
        .contact-item {
            margin: 10px 0;
        }
    </style>
</head>
<body>

<!-- Navbar (sit on top) -->
<div class="w3-top">
  <div class="w3-bar w3-white w3-padding w3-card" style="letter-spacing:4px;">
    <a href="#home" class="w3-bar-item w3-button">BellMondo Cafe</a>
    <!-- Right-sided navbar links. Hide them on small screens -->
    <div class="w3-right w3-hide-small">
      <a href="#about" class="w3-bar-item w3-button">About</a>
      <a href="#menu" class="w3-bar-item w3-button">Menu</a>
      <a href="#testimoni" class="w3-bar-item w3-button">Testimoni</a>
      <a href="#contact" class="w3-bar-item w3-button">Contact</a>
    </div>
  </div>
</div>

<!-- Carousel -->
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel" data-interval="4000">
    <ol class="carousel-indicators">
        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner" style="height: 500px;">
        <div class="carousel-item active">
            <img src="img/Lobster Thermidor.jpg" class="d-block w-100" alt="Lobster Thermidor">
            <div class="carousel-caption d-none d-md-block">
                <h5>Lobster Thermidor</h5>
            </div>
        </div>
        <div class="carousel-item">
            <img src="img/Peking Duck.jpg" class="d-block w-100" alt="Peking Duck">
            <div class="carousel-caption d-none d-md-block">
                <h5>Peking Duck</h5>
            </div>
        </div>
        <div class="carousel-item">
            <img src="img/Opera Cake.jpg" class="d-block w-100" alt="Opera Cake">
            <div class="carousel-caption d-none d-md-block">
                <h5>Opera Cake</h5>
            </div>
        </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>

<!-- Page content -->
<div class="w3-content" style="max-width:1100px">

  <!-- About Section -->
  <div class="w3-row w3-padding-64" id="about">
    <div class="w3-col m6 w3-padding-large w3-hide-small">
     <img src="img/logo.jpg" class="w3-round w3-image w3-opacity-min" alt="Logo" width="600" height="750" style="margin-top: 20px;">
    </div>

    <div class="w3-col m6 w3-padding-large">
      <h1 class="w3-center">Cafe BellMondo</h1><br>
      <h5 class="w3-center">Tradisi sejak 1889</h5>
      <p class="w3-large">Cafe ini didirikan di Medan,Sumatera Utara oleh Bayu Anggoro dalam dengan visi, dedikasi yang tinggi untuk menyajikan pengalaman kafe mewah kepada para pelanggan setia, dan telah menjadi destinasi yang terkenal untuk pecinta makanan mewah. Kami hanya menggunakan bahan-bahan <span class="w3-tag w3-light-grey">musiman</span> yang berkualitas terbaik.</p>
      <p class="w3-large w3-text-grey w3-hide-medium">Kami mengutamakan kualitas dan keaslian dalam setiap hidangan kami. Setiap kunjungan ke Cafe BellMondo adalah pengalaman yang tak terlupakan, dengan nuansa tradisional yang kental namun tetap memancarkan kemewahan.</p>
    </div>
  </div>
  
  <hr>
  
  <!-- Menu Section -->
  <div class="w3-row w3-padding-64" id="menu">
    <h1 class="w3-center">Our Menu</h1><br>
    <div class="menu-container">
      <div class="w3-card-4 w3-margin w3-white menu-card">
        <img src="img/Lobster Thermidor.jpg" alt="Lobster Thermido" style="width:100%">
        <div class="w3-container">
          <h3><b>Lobster Thermido</b></h3>
          <h5>Hidangan mewah yang memadukan kelembutan daging lobster dengan saus krim yang kaya dan keju panggang, menciptakan perpaduan rasa yang luar biasa memanjakan lidah. <span class="w3-opacity"></span></h5>
        </div>
        <div class="w3-container">
          <button class="w3-button w3-block w3-black"><a href="https://wa.me/083842803207?text=kak%20saya%20mau%20Order%20" style="text-decoration: none; color: white;">Order</a></button>
        </div>
      </div>
      <div class="w3-card-4 w3-margin w3-white menu-card">
        <img src="img/Peking Duck.jpg" alt="Peking Duck" style="width:100%">
        <div class="w3-container">
          <h3><b>Peking Duck</b></h3>
          <h5>Sajian ikonik yang menawarkan perpaduan sempurna antara kulit bebek yang renyah, daging yang lembut, dan saus hoisin yang manis gurih, menjadikannya pengalaman kuliner yang tak terlupakan. <span class="w3-opacity"></span></h5>
        </div>
        <div class="w3-container">
          <button class="w3-button w3-block w3-black"><a href="https://wa.me/083842803207?text=kak%20saya%20mau%20Order%20" style="text-decoration: none; color: white;">Order</a></button>
        </div>
      </div>
      <div class="w3-card-4 w3-margin w3-white menu-card">
        <img src="img/Opera Cake.jpg" alt="Opera Cake" style="width:100%">
        <div class="w3-container">
          <h3><b>Opera Cake</b></h3>
          <h5>Opera Cake adalah kue elegan dengan lapisan almond sponge cake, krim mentega kopi, dan ganache cokelat,menciptakan harmoni rasa yang kaya dan mewah dalam setiap gigitan. <span class="w3-opacity"></span></h5>
        </div>
        <div class="w3-container">
          <button class="w3-button w3-block w3-black"><a href="https://wa.me/083842803207?text=kak%20saya%20mau%20Order%20" style="text-decoration: none; color: white;">Order</a></button>
        </div>
      </div>
    </div>
  </div>

  <hr>

  <!-- Testimonials Section -->
  <div class="w3-container w3-padding-64" id="testimoni">
    <h1 class="w3-center">Testimoni</h1><br>
    <div class="testimoni-container">
      <div class="w3-card-4 w3-margin w3-white testimoni-card">
        <img src="img/like1.jpg" alt="John Doe" style="width: 100%">
        <p>"The food was absolutely wonderful, from preparation to presentation, very pleasing. Thank you for an amazing experience!"</p>
        <h5><b>- John Doe</b></h5>
      </div>
      <div class="w3-card-4 w3-margin w3-white testimoni-card">
        <img src="img/like2.jpg" alt="Jane Smith" style="width: 100%">
        <p>"Everything was perfect, the food was delicious, the service was outstanding. I am truly impressed!"</p>
        <h5><b>- Jane Smith</b></h5>
      </div>
      <div class="w3-card-4 w3-margin w3-white testimoni-card">
        <img src="img/like3.jpg" alt="Michael Brown" style="width: 100%">
        <p>"I was delighted with the quality of the food and the impeccable service provided. Kudos to the team!"</p>
        <h5><b>- Michael Brown</b></h5>
      </div>
    </div>
  </div>

  <hr>

  <!-- Contact Section -->
  <div class="w3-container w3-padding-64" id="contact">
    <h1 align="center">Contact</h1><br>
    <div class="contact-container">
      <div class="contact-details">
        <div class="contact-item">
          <p class="w3-text-blue-grey w3-large"><b>Phone: 0838-4280-3207</b></p>
        </div>
        <div class="contact-item">
          <p class="w3-text-blue-grey w3-large"><b>Email: bayudeveloper07@gmail.com</b></p>
        </div>
        <div class="contact-item">
          <p class="w3-text-blue-grey w3-large"><b>Address: Jalan Sisingamangaraja, Medan Kota</b></p>
        </div>
      </div>
      <div class="contact-form">
        <form action="masukan.php" method="post">
          <p><input class="w3-input w3-padding-16" type="text" placeholder="Name" required name="name"></p>
          <p><input class="w3-input w3-padding-16" type="email" placeholder="Email" required name="email"></p>
          <p><textarea class="w3-input w3-padding-16" placeholder="Message" required name="message"></textarea></p>
          <p><button class="w3-button w3-light-grey w3-section" type="submit">SEND MESSAGE</button></p>
        </form>
      </div>
    </div>
  </div>

<!-- End page content -->
</div>

  <!-- Footer -->
  <footer class="w3-center w3-light-grey w3-padding-32">
    <p>&copy; 2024 Powered by Bayu Anggoro. All Rights Reserved.</p>
  </footer>

  <!-- Bootstrap JS, Popper.js, and jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
