﻿Imports System.Data.Odbc
Public Class FrmJual

End Class