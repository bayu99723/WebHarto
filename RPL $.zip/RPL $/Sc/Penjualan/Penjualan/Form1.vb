﻿Imports System.Data.Odbc
Public Class FrmBarang
    Dim Conn As OdbcConnection
    Dim Cmd As OdbcCommand
    Dim Ds As DataSet
    Dim Da As OdbcDataAdapter
    Dim Rd As OdbcDataReader
    Dim MyDB As String
    'Membuat Koneksi
    Sub Koneksi()
        ' Memanggil database yaitu nama database kita adalah kampus
        MyDB = "Driver={MySQL ODBC 5.3 ANSI Driver};Database=penjualan;Server=localhost;uid=root"
        Conn = New OdbcConnection(MyDB)
        If Conn.State = ConnectionState.Closed Then Conn.Open()
    End Sub

    Sub KondisiAwal()
        ' Textbox1, textbox2, textbox3, textbox4 kita kosongkan pertama kali
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox7.Text = ""

        ' Textbox1, textbox2, textbox3, textbox4.enabled = false artinya formnya kita matikan  
        TextBox1.Enabled = False
        TextBox2.Enabled = False
        TextBox3.Enabled = False
        TextBox4.Enabled = False
        TextBox5.Enabled = False
        TextBox6.Enabled = False
        TextBox7.Enabled = False
        ' Textbox1 yang berarti form nim kita maksimalkan hanya bisa 15 huruf/angka


        ' Button1, Button2, Button3, Button4 kita tambahkan text masing - masing yaitu input, edit, hapus, tutup
        Button1.Text = "TAMBAH"
        Button2.Text = "UBAH"
        Button3.Text = "HAPUS"
        Button4.Text = "TUTUP"

        ' Button1, Button2, Button3, Button4 kita aktifkan dengan menggunakan perintah true
        Button1.Enabled = True
        Button2.Enabled = True
        Button3.Enabled = True
        Button4.Enabled = True

        ' Panggil koneksi yang sudah kita buat sub Koneksi()
        Call Koneksi()

        ' Memanggil table yang sudah kita buat yaitu mahasiswa
        Da = New OdbcDataAdapter("Select * From barang", Conn)
        Ds = New DataSet
        Da.Fill(Ds, "barang")
        DataGridView1.DataSource = Ds.Tables("barang")
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call KondisiAwal()
    End Sub

    Sub FieldAktif()
        ' untuk mengaktifkan form
        TextBox1.Enabled = True
        TextBox2.Enabled = True
        TextBox3.Enabled = True
        TextBox4.Enabled = True
        TextBox5.Enabled = True
        TextBox6.Enabled = True
        TextBox7.Enabled = True
        TextBox1.Focus()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)
        ' if button1.text yang textnya "input" maka akan berubah menjadi button "simpan"
        If Button1.Text = "TAMBAH" Then
            Button1.Text = "SIMPAN"
            ' lalu button2 dan button3 tidak aktif dan button4 kita ubah menjadi tulisan "batal"
            Button2.Enabled = False
            Button3.Enabled = False
            Button4.Text = "BATAL"
            ' lalu kita panggil FieldAktif() yang mana textbox1,textbox2,textbox3,textbox4 akan diaktifkan
            Call FieldAktif()
        Else
            ' if textbox1, textbox2, textbox3 dan textbox3 kosong maka muncul alert pastikan semua field terisi
            ' ini artinya disebut validasi
            If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or TextBox5.Text = "" Or TextBox6.Text = "" Or TextBox7.Text = "" Then
                MsgBox("Pastikan semua field terisi")
            Else
                ' Jika semua form terisi, maka kita panggil Koneksi() ke database
                Call Koneksi()
                ' lalu kita masukan data kita ke table mahasiswa (insert into mahasiswa .....)
                Dim InputData As String = "Insert into barang values('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "','" & TextBox7.Text & "')"
                Cmd = New OdbcCommand(InputData, Conn)
                Cmd.ExecuteNonQuery()
                ' lalu kita tampilkan message "input data berhasil"
                MsgBox("Input data berhasil")
                ' lalu kita kembalikan ke KondisiAwal()
                Call KondisiAwal()
            End If
        End If
    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs)
        ' if chr 13 kita tekan, btw chr 13 itu adalah enter ya 
        If e.KeyChar = Chr(13) Then
            ' setelah tekan entar maka Koneksi() akan terpanggil
            Call Koneksi()
            ' lalu ketika kita masukan nim di textbox1 (tekan enter) 
            ' selanjutnya tolong panggilkan table mahasiswa dan tolong isi isi form textbox2 dan textbox3 dan textbox4 

            Cmd = New OdbcCommand("Select * from barang where kode_barang='" & TextBox1.Text & "'", Conn)
            Rd = Cmd.ExecuteReader
            Rd.Read()
            ' if kita panggil nim lalu tekan enter maka otomatis textbox2, textbox3, dan textbox4 akan terisi secara otomatis
            If Rd.HasRows Then
                TextBox2.Text = Rd.Item("nama_barang")
                TextBox3.Text = Rd.Item("jenis_barang")
                TextBox4.Text = Rd.Item("satuan_barang")
                TextBox5.Text = Rd.Item("harga_beli")
                TextBox6.Text = Rd.Item("harga_jual")
                TextBox7.Text = Rd.Item("stok")

            Else
                ' Jika nim yang kita ketikan salah, maka akan menampilkan alert atau message ("data tidak ada")
                MsgBox("Data Tidak Ada")
            End If
        End If
    End Sub

    ' Ini adalah proses EDIT
    Private Sub Button2_Click(sender As Object, e As EventArgs)
        'If Button2 edit kita klik maka dia akan berubah menjadi tulisan "update"
        If Button2.Text = "UBAH" Then
            Button2.Text = "SIMPAN"
            'button1 dan button2 akan kita false artinya tidak berfungsi
            Button1.Enabled = False
            Button3.Enabled = False

            'button4 kita ganti tulisan menjadi batal
            Button4.Text = "BATAL"
            ' Lalu kita panggil FieldAktif() yang mana textbox1, textbox2, textbox3 dan textbox 4 kita aktifkan
            Call FieldAktif()
        Else
            ' ini adalah validasi jika textbox1, textbox2, textbox3 dan textbox 4 tidak terisi maka akan muncul alert ("pastikan semua terisi)
            If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or TextBox5.Text = "" Or TextBox6.Text = "" Or TextBox7.Text = "" Then
                MsgBox("Pastikan semua field terisi")
            Else
                ' jika semua terisi panggil Koneksi()
                Call Koneksi()
                ' kita update table mahasiswa
                Dim EditData As String = "Update barang set nama_barang ='" & TextBox2.Text & "',jenis_barang='" & TextBox3.Text & "',satuan_barang='" & TextBox4.Text & "',harga_jual='" & TextBox5.Text & "',harga_beli='" & TextBox6.Text & "',stok='" & TextBox7.Text & "' where kode_barang='" & TextBox1.Text & "'"
                Cmd = New OdbcCommand(EditData, Conn)
                Cmd.ExecuteNonQuery()
                ' jika berhasil tampilkan alert / message ("edit data berhasil")
                MsgBox("Edit data berhasil")
                ' setelah semua sudah tolong tampilkan KondisiAwal()
                Call KondisiAwal()
            End If
        End If
    End Sub

    ' Button3 adalah button hapus
    Private Sub Button3_Click(sender As Object, e As EventArgs)
        ' Jika button3.text yang mana textnya adalah hapus maka kita ubah texttnya menjadi delete  
        If Button3.Text = "HAPUS" Then
            Button3.Text = "DELETE"
            ' button1 non aktifkan
            Button1.Enabled = False
            ' button2 juga kita non aktifkan, jadi dia ga bisa di klik sama sekali ketika button hapus kita klik
            Button2.Enabled = False
            ' button4.text kita ubah textnya dari tutup menjadi batal
            Button4.Text = "BATAL"
            ' setelah itu kita aktifkan FieldAktif() yang mana artinya kita mengaktifkan textbox1, textbox2, textbox3 dan textbox4
            Call FieldAktif()
        Else
            ' Ini adalah validasi
            ' jika field tidak terisi maka tidak akan bisa di hapus
            If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or TextBox5.Text = "" Or TextBox6.Text = "" Or TextBox7.Text = "" Then
                MsgBox("Pastikan semua field terisi")
            Else
                ' jika sudah kita isi fieldnya maka bisa kita hapus, prosesnya adalah
                ' kita panggil Koneksi()
                Call Koneksi()
                ' lalu kita panggil table mahasiswa lalu dia bilang "tolongin aku dong, aku mau hapus dengan nim xxx tolong di bantu ya. makasih:)"
                Dim HapusData As String = "delete from barang where kode_barang='" & TextBox1.Text & "'"
                Cmd = New OdbcCommand(HapusData, Conn)
                Cmd.ExecuteNonQuery()
                ' kalau berhasil kita tampilkan alert / message dengan tulisan "hapus data berhasil"
                MsgBox("Hapus data berhasil")
                ' lalu kita panggil kondisiAwal()
                Call KondisiAwal()
            End If
        End If
    End Sub

    ' ini adalah proses button4 yaitu tutup
    Private Sub Button4_Click(sender As Object, e As EventArgs)
        ' Jika button4 textnya TUTUP maka tolong end atau exit atau keluar dari aplikasi
        If Button4.Text = "TUTUP" Then
            End
            ' namun kalau tulisannya BATAL maka kita panggil KondisiAwal()
        Else
            Call KondisiAwal()
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs)

    End Sub
End Class