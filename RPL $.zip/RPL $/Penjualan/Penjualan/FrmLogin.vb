﻿Imports System.Data.Odbc

Public Class FrmLogin
    Dim Conn As OdbcConnection
    Dim Cmd As OdbcCommand
    Dim Rd As OdbcDataReader
    Dim MyDB As String

    'Membuat Koneksi
    Sub Koneksi()
        ' Memanggil database yaitu nama database kita adalah kampus
        MyDB = "Driver={MySQL ODBC 5.3 ANSI Driver};Database=dblogin;Server=localhost;uid=root"
        Conn = New OdbcConnection(MyDB)
        If Conn.State = ConnectionState.Closed Then Conn.Open()
    End Sub

    Private Sub FrmLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Pemanggilan Koneksi pada saat form dimuat
        Koneksi()
    End Sub

    Private Sub btnBatal_Click(sender As Object, e As EventArgs) Handles btnBatal.Click
        If MessageBox.Show("Yakin Ingin Membatalkan Login?", "Konfirmasi", MessageBoxButtons.YesNo, MessageBoxIcon.Information) = Windows.Forms.DialogResult.Yes Then
            BerandaUser.Close()
        End If
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Try
            Koneksi()

            Dim strUser As String = "SELECT * FROM tbl_user WHERE username = ? AND pass = ?"
            Cmd = New OdbcCommand(strUser, Conn)
            Cmd.Parameters.AddWithValue("@username", txtUsername.Text)
            Cmd.Parameters.AddWithValue("@pass", txtPass.Text)

            Rd = Cmd.ExecuteReader()

            If Rd.HasRows Then
                ' Login berhasil, sembunyikan FrmLogin
                Me.Hide()

                ' Tampilkan FrmJual
                Dim frmJual As New BerandaUser()
                frmJual.Show()
                ' Tutup koneksi dan buka koneksi kembali untuk login berikutnya
                Rd.Close()
                Conn.Close()
                Exit Sub
            End If

            ' Jika tidak ditemukan di tbl_user, coba cari di tbl_admin
            Rd.Close()

            Dim strAdmin As String = "SELECT * FROM tbl_admin WHERE username = ? AND pass = ?"
            Cmd = New OdbcCommand(strAdmin, Conn)
            Cmd.Parameters.AddWithValue("@username", txtUsername.Text)
            Cmd.Parameters.AddWithValue("@pass", txtPass.Text)

            Rd = Cmd.ExecuteReader()

            If Rd.HasRows Then
                ' Login berhasil, sembunyikan FrmLogin
                Me.Hide()

                ' Tampilkan FrmBeranda
                Dim frmBeranda As New FrmBeranda()
                frmBeranda.Show()
            Else
                MessageBox.Show("Login gagal, username atau Password salah", "Informasi", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                txtPass.Text = ""
                txtUsername.Text = ""
                txtUsername.Focus()
            End If
        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
        Finally
            ' Tutup koneksi dan pembaca data
            If Rd IsNot Nothing Then Rd.Close()
            If Conn IsNot Nothing Then Conn.Close()
        End Try
    End Sub
End Class
