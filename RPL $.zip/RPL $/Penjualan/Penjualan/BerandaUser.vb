﻿Imports System.Data.Odbc
Public Class BerandaUser
    Dim Conn As OdbcConnection
    Dim Cmd As OdbcCommand
    Dim Ds As DataSet
    Dim Da As OdbcDataAdapter
    Dim Rd As OdbcDataReader
    Dim MyDB As String
    'Membuat Koneksi
    Sub Koneksi()
        ' Memanggil database yaitu nama database kita adalah kampus
        MyDB = "Driver={MySQL ODBC 5.3 ANSI Driver};Database=penjualan;Server=localhost;uid=root"
        Conn = New OdbcConnection(MyDB)
        If Conn.State = ConnectionState.Closed Then Conn.Open()

    End Sub

    Sub KondisiAwal()

        Call Koneksi()

        ' Memanggil table yang sudah kita buat yaitu mahasiswa
        Da = New OdbcDataAdapter("SELECT kode_barang, nama_barang, jenis_barang, satuan_barang, harga_jual, stok FROM barang;", Conn)
        Ds = New DataSet
        Da.Fill(Ds, "barang")
        DataGridView1.DataSource = Ds.Tables("barang")

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
        FrmLogin.Show()
    End Sub



    Private Sub BerandaUser_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        KondisiAwal()
    End Sub
End Class
